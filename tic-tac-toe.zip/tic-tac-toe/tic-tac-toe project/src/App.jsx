
function App() {
  

  return (
    <h1>React Tic-Tac-Toe</h1>
  )
}

export default App
